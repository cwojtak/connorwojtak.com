ATTENTION: Go to dist and create a shortcut to numgame and use the shortcut.
Extract it into a folder also.